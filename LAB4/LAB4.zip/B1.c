#include <stm32f4xx.h>

#define RCC_AHB1ENR (*((volatile unsigned int*)0x40023830))
#define GPIOA_MODER (*((volatile unsigned int*)0x40020000))
#define GPIOA_BSRR  (*((volatile unsigned int*)0x40020018))
#define GPIOA_ODR  (*((volatile unsigned int*)0x40020014))
	
#define GPIOB_MODER (*((volatile unsigned int*)0x40020400))
#define GPIOB_BSRR  (*((volatile unsigned int*)0x40020418))
#define GPIOB_IDR  (*((volatile unsigned int*)0x40020410))

void delay(int t);

int main()
{

	  RCC_AHB1ENR |=  3;               /* enable GPIOA & GPIOB clock */
    
    GPIOA_MODER &= ~0x0000000C ;     /* clear pin mode */
    GPIOA_MODER |=  0x55555555 ;     /* set pin PA0-PA7 to output mode */
		GPIOA_ODR &= ~0x00000000 ;       /* clear pin mode */
	
	  GPIOB_MODER &= ~0x0000000C ;     /* clear pin mode */
    GPIOB_MODER |=  0x00000000 ;     /* set ALL pins to input mode */
	  GPIOB_IDR &= ~0x00000000 ;       /* clear pin mode */

		unsigned int seg = 0x00000000;
	
	
		while(1)
		{

					if( (GPIOB_IDR & 9)== 9){GPIOA_ODR = seg | 0x0009;}
					else if( (GPIOB_IDR & 8)== 8){GPIOA_ODR = seg | 0x0008;}
					else if( (GPIOB_IDR & 7)== 7){GPIOA_ODR = seg | 0x0007;}	
					else if( (GPIOB_IDR & 6)== 6){GPIOA_ODR = seg | 0x0006;}	
					else if( (GPIOB_IDR & 5)== 5){GPIOA_ODR = seg | 0x0005;}		
					else if( (GPIOB_IDR & 4)== 4){GPIOA_ODR = seg | 0x0004;}				
					else if( (GPIOB_IDR & 3)== 3){GPIOA_ODR = seg | 0x0003;}
					else if( (GPIOB_IDR & 2)== 2){GPIOA_ODR = seg | 0x0002;}
					else if( (GPIOB_IDR & 1)== 1){GPIOA_ODR = seg | 0x0001;}
					else if( (GPIOB_IDR & 0)== 0){GPIOA_ODR = seg | 0x0000;}

					delay(1);
		
	}
	
}


void delay(int t) // Delay function
{
	int n;
	for(n=0;n<(t*100000);n++);
}