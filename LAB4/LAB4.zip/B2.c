#include "stm32f4xx.h"


void delay(int t);

int main(void)
{
	RCC->AHB1ENR |=  1;  //clock PORTA
	GPIOA->MODER = 0x00005555; // output and input PORTA
	GPIOA->PUPDR |= (1UL << 8);
	GPIOA->PUPDR |= (1UL << 9);
	int mode = 0;
	int count = 0;
	int seg =0x00000000;
	
	while (1)
	{
		
		if((GPIOA->IDR & 256) != 256)
		{
			mode=1; // up counting
		}
		if((GPIOA->IDR & 512) != 512)
		{
			mode=2; // down counting
		}
		
		switch(count)
		{
			case 0:seg = 0x00000000;break;
			case 1:seg = 0x00000001;break;
			case 2:seg = 0x00000001;break;
			case 3:seg = 0x00000002;break;
			case 4:seg = 0x00000003;break;
			case 5:seg = 0x00000005;break;
			case 6:seg = 0x00000008;break;
			case 7:seg = 0x00000013;break;
			case 8:seg = 0x00000021;break;
			case 9:seg = 0x00000034;break;
			case 10:seg = 0x00000055;break;
			case 11:seg = 0x00000089;break;
		}
			
			if(mode ==1) // up counter
				{
				  GPIOA -> ODR = seg;
					count++;
				}
			else if(mode == 2)// down counter
				{ 
				  GPIOA -> ODR = seg; 
					count--;
			  }	
			if(count > 13)
			{
				count = 0;
			}
			if(count < 0)
			{
				count = 13;
			}
			delay(1);
			mode = 0;
	}
	    
		
 }


void delay(int t) // Delay function
{
	int n;
	for(n=0;n<(t*200000);n++);
}
