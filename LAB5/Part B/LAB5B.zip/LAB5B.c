#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"

int main(void)
{
	SystemCoreClockUpdate();
	HAL_Init();
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
	
	GPIO_InitTypeDef PinConfig;
	PinConfig.Pin = GPIO_PIN_5;
	PinConfig.Mode = GPIO_MODE_OUTPUT_PP;
	PinConfig.Pull = GPIO_NOPULL;
	PinConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &PinConfig);
	
	PinConfig.Pin = GPIO_PIN_6;
	HAL_GPIO_Init(GPIOA, &PinConfig);
	
	PinConfig.Pin = GPIO_PIN_13;
	PinConfig.Mode = GPIO_MODE_INPUT;
	PinConfig.Pull = GPIO_NOPULL;
	PinConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOC, &PinConfig);
	
	SYSCFG->EXTICR[3] |= ( 2 << 4 );
	EXTI->RTSR |= ( 1 << 13);
	EXTI->IMR |= (1 << 13);
	NVIC_EnableIRQ(EXTI15_10_IRQn);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	while (1)
	{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_Delay(1);
	}
	return 0;
}

void SysTick_Handler(void)
{
  HAL_IncTick();
}

void EXTI15_10_IRQHandler() {
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
	EXTI->PR |= (1 << 13);
	NVIC_ClearPendingIRQ(EXTI15_10_IRQn);
}
